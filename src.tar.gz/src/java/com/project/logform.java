/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.project;

import com.mysql.jdbc.Statement;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection; 
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;

///long User_ID;
/**
 *
 * @author hp
 */
public class logform extends HttpServlet {
   
    long User_ID;
public static void main(String args[]) 
        throws ClassNotFoundException, InstantiationException 
    {
     }  
   
     
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException, ClassNotFoundException 
    {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

    }
    
    
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int c = 0;
        int d = 0;
       try {  
        try {
                Class.forName("com.mysql.jdbc.Driver");
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(logform.class.getName()).log(Level.SEVERE, null, ex);
            }
            
         String k=request.getParameter("user");
         String k1 =request.getParameter("pass");
            Connection dbCon = DriverManager.getConnection(  
                    "jdbc:mysql://localhost:3306/test1", "root", "admin");  

            String query ="select password from authenticate where user = '"+k+"' ";
            String query1 ="select name from authenticate where user = '"+k+"' ";

            Statement stmt = null;
            ResultSet rs = null;
            
   ////         int c;
            //getting PreparedStatment to execute query
            stmt = (Statement) dbCon.prepareStatement(query);
            Statement stmt1 = (Statement) dbCon.prepareStatement(query1);
            
            //Resultset returned by query
            rs = stmt.executeQuery(query);
            ResultSet rs1 = stmt1.executeQuery(query1);

            while(rs.next()){
            c = rs.getInt(1);
            }
            
            while(rs1.next()){
            d = rs.getInt(1);
           
            }

            }
       catch (SQLException ex)
        {
        } 
            String k=request.getParameter("user");
            String k1 =request.getParameter("pass");
            ////String k2="daga" ;
    //////    processRequest(request, response);
            User_ID=Long.parseLong(k);
            int kk=Integer.parseInt(k1);
          
            response.setContentType("text/html;charset=UTF-8");
            PrintWriter out = response.getWriter();
        Object list = null;
        try {
            if(User_ID==4444 && kk==4444)
            {
                    out.println("<html>");
                    out.println("<head>");
                    out.println("<title> Admin Login</title>");
                    out.println("</head>");
                    out.println("<body>");
                    out.println("<center>");
              
              out.println("<h1>  Admin LogIn</h1>");
              out.println("<a href=updateitem.jsp>");
              out.println("<h3> Update Item </h3>");
              out.println("</a>");
              out.println("<a href=manageuser.jsp>");
              out.println("<h3> Manage Users </h3>");
              out.println("</a>");
              out.println("<a href=Log.jsp>Sign Out</a>");
              out.println("</center>");
                    out.println("</body>");
                    out.println("</html>");
            }
            else{
            if(kk==c)
            {
                 ServletContext sc = this.getServletContext();
                 request.setAttribute("name",d);
                 request.setAttribute("data", User_ID);
                 RequestDispatcher rd = sc.getRequestDispatcher("/userstart.jsp");
          rd.forward(request, response);
          
       
            //// TODO output your page here
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet log</title>");  
            out.println("</head>");
            out.println("<body>");
            out.println("<center>");
            out.println("<h1>");
            out.println(User_ID);
            out.println("</h1>");
            out.println("<form action=disp method=get>");
       //// <h1>Hello World!</h1>
            out.println("<a href=givrate.jsp >Rate Item</a>");
        
        out.println("<input type=text name= n1 disabled=disabled value='"+User_ID+"'>");
        out.println("<input type=text name=n2 >");
        /////out.println("<input type=text name=n2  value='"+User_ID+"' >");
        out.println("<input type=submit name=submit value=submit>");
        
        out.println("</form>");
            out.println("</center>");
            out.println("</body>");
            out.println("</html>");
            }
             else
            {
                out.println("<html>");
                out.println("<head>");
                out.println("<title>FAILED</title>");
                out.println("</head>");
                out.println("<body bgcolor=YELLOW>");
                out.println("<center>");
                out.println("<a href=Log.jsp>LOGIN enter valid username and password</a>");
                out.println("</center>");
                out.println("</body>");
                out.println("</html>");
                
            }
            }
        } finally {            
            out.close();
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
