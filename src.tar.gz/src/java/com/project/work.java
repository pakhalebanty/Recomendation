/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.project;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author hp
 */
public class work extends HttpServlet {

    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }    
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        PrintWriter out = response.getWriter();
          ArrayList list=new ArrayList();
        Integer i = 0;
       try {  
        try {
                Class.forName("com.mysql.jdbc.Driver");
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(adminform.class.getName()).log(Level.SEVERE, null, ex);
            }
            
         ///String a =request.getParameter("del");
         ///long delname=Long.parseLong(a);
          
         Connection dbCon = (Connection) DriverManager.getConnection(  
                    "jdbc:mysql://localhost:3306/test1", "root", "admin");  

            
         String query =" select * from bx";

            Statement stmt = null;
            ResultSet rs = null;
           
            stmt = (Statement) dbCon.prepareStatement(query);

            rs = stmt.executeQuery(query);
        
         while(rs.next())
            {
               list.add(rs.getString("ISBN")); 
               list.add(rs.getString("title"));
               list.add(rs.getString("author"));
               list.add(rs.getString("year"));
               list.add(rs.getString("publisher"));
               list.add(rs.getString("url"));
            
            }
            ServletContext sc = this.getServletContext();
request.setAttribute("data", list);
          ///  out.println("<img src=/one.jpg>");
            out.println("</body>");
            out.println("</html>");
       RequestDispatcher rd = sc.getRequestDispatcher("/watch.jsp");
       rd.forward(request, response);
       }
       
       catch (SQLException ex)
         {
                out.println(ex);
         } 
       finally 
        {            
            out.close();
        }
           
    }   
   @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
