/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.project;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author hp
 */
public class givrateform extends HttpServlet {

    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            response.setContentType("text/html;charset=UTF-8");
            PrintWriter out = response.getWriter();
        try {
            /* TODO output your page here
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet givrateform</title>");  
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet givrateform at " + request.getContextPath () + "</h1>");
            out.println("</body>");
            out.println("</html>");
             */
        } finally {            
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         PrintWriter out = response.getWriter();  
        String k=request.getParameter("n3");
          String k1 =request.getParameter("n4");
          String k3 =request.getParameter("n5");
          
         
          
        Integer i = 0;
       try {  
        try {
                Class.forName("com.mysql.jdbc.Driver");
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(givrateform.class.getName()).log(Level.SEVERE, null, ex);
            }
            
         Connection dbCon = (Connection) DriverManager.getConnection(  
                    "jdbc:mysql://localhost:3306/test1", "root", "admin");  

            
         String query ="insert into bx_book_ratings(User_ID,ISBN,Book_Rating) "+
                 "values ('"+k+"','"+k1+"','"+k3+"') ";

            Statement stmt = null;
            ResultSet rs = null;
           
            stmt = (Statement) dbCon.prepareStatement(query);

            i = stmt.executeUpdate(query);
            out.println(i);
            
            }
       catch (SQLException ex)
        {
                out.println(ex);
        } 
            
            response.setContentType("text/html;charset=UTF-8");
            ////PrintWriter out = response.getWriter();
        try {
            if(i!=0)
            {
                    out.println("<html>");
                    out.println("<head>");
                    out.println("<title> Success</title>");
                    out.println("</head>");
                    out.println("<body bgcolor=YELLOW>");
                    out.println("<p><h1> Successfully Rated!!!!</h1> </p>");
                    out.println("<a href=userstart.jsp>");
                    out.println("RETURN</a>");
                    out.println("</body>");
                    out.println("</html>");
            }
            else{
            //// TODO output your page here
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Rating Failed!!!!</title>");  
            out.println("</head>");
            out.println("<body>");
            out.println("<a href=signup.jsp> sign up again.....");
            out.println("</a>");
            out.println("</body>");
            out.println("</html>");
            
            }
        } finally {            
            out.close();
        }
    
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
