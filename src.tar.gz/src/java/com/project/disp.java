/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.project;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;
import java.io.IOException;
import java.io.PrintWriter;
////import java.util.ArrayList;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.impl.model.jdbc.MySQLJDBCDataModel;
import org.apache.mahout.cf.taste.impl.neighborhood.NearestNUserNeighborhood;
import org.apache.mahout.cf.taste.impl.recommender.GenericUserBasedRecommender;
import org.apache.mahout.cf.taste.impl.similarity.PearsonCorrelationSimilarity;
import org.apache.mahout.cf.taste.model.JDBCDataModel;
import org.apache.mahout.cf.taste.neighborhood.UserNeighborhood;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;
import org.apache.mahout.cf.taste.recommender.Recommender;
import org.apache.mahout.cf.taste.similarity.UserSimilarity;

/**
 *
 * @author Administrator
 */
public class disp extends HttpServlet {
   
    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            /* TODO output your page here
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet disp</title>");  
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet disp at " + request.getContextPath () + "</h1>");
            out.println("</body>");
            out.println("</html>");
            */
        } finally { 
            out.close();
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    //<editor-fold defaultstate="collapsed" desc="comment">
    @Override
    //</editor-fold>
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        //processRequest(request, response);
        String[] z=request.getParameterValues("c");
        String[] x=request.getParameterValues("d");
              String k=request.getParameter("n1");
            String k1 =request.getParameter("n2");
        //double kk=Double.parseDouble(n1);
            long k2 = 0 ;
            float k3 = 0 ;
        ArrayList list=new ArrayList();
      // long User_ID=277427;
        long User_ID=Long.parseLong(k);
        int kk=Integer.parseInt(k1);
      /*  int s=Integer.parseInt(z);
        int t=Integer.parseInt(x);*/
      /* ServletContext sc = this.getServletContext();
       RequestDispatcher rd = sc.getRequestDispatcher("/index.jsp");
       rd.forward(request, response);
    */
MysqlDataSource dataSource = new MysqlDataSource ();
dataSource.setServerName("localhost");
dataSource.setUser("root");
dataSource.setPassword("admin");
dataSource.setDatabaseName("test1");
JDBCDataModel model = new MySQLJDBCDataModel(
dataSource, "bx_book_ratings", "User_ID",
"ISBN", "Book_Rating ",null);


  PrintWriter out = response.getWriter();
        int c;
        try {
            out.println("<html>");
            out.println("<head>");
            out.println("<title>disp page</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Group 14 :Slope-one Algortihm  </h1>");



  out.println("For user"+User_ID);
 ////// Recommender recommender =new SlopeOneRecommender(model);
      UserSimilarity similarity = new PearsonCorrelationSimilarity(model);

    UserNeighborhood neighborhood = new NearestNUserNeighborhood (2, similarity, model);
        Recommender recommender = new GenericUserBasedRecommender (model, neighborhood, similarity);
  
 List<RecommendedItem> recommendations = recommender.recommend(User_ID,kk);
    for (RecommendedItem recommendation : recommendations)
    {
    k2 = recommendation.getItemID();
    k3 = recommendation.getValue();
    out.println(k2);
    out.println(k3);
   request.setAttribute("myname",k3);
   try {  
        try {
                Class.forName("com.mysql.jdbc.Driver");
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(logform.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            Connection dbCon = (Connection) DriverManager.getConnection(  
                    "jdbc:mysql://localhost:3306/test1", "root", "admin");  

            String query ="select * from bx where ISBN = '"+k2+"' ";

            Statement stmt = null;
            ResultSet rs = null;
            
   ////         int c;
            //getting PreparedStatment to execute query
            stmt = (Statement) dbCon.prepareStatement(query);

            //Resultset returned by query
            rs = stmt.executeQuery(query);

            while(rs.next())
            {
               list.add(rs.getString("ISBN")); 
               list.add(rs.getString("title"));
               list.add(rs.getString("author"));
               list.add(rs.getString("year"));
               list.add(rs.getString("publisher"));
               list.add(rs.getString("url"));
            
            }

            }
       catch (SQLException ex)
        {
        } 
    }

ServletContext sc = this.getServletContext();
request.setAttribute("data", list);
          ///  out.println("<img src=/one.jpg>");
            out.println("</body>");
            out.println("</html>");
       RequestDispatcher rd = sc.getRequestDispatcher("/index.jsp");
       rd.forward(request, response);
        }
      catch (TasteException ex) {
          Logger.getLogger(disp.class.getName()).log(Level.SEVERE, null, ex);
         

        }


        finally {
            out.close();
        }



    } 

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
