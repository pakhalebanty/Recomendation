/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.project;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author hp
 */
public class register extends HttpServlet {

    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            /* TODO output your page here
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet register</title>");  
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet register at " + request.getContextPath () + "</h1>");
            out.println("</body>");
            out.println("</html>");
             */
        } finally {            
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        Integer c = 0;
        Integer i = 0;
       try {  
        try {
                Class.forName("com.mysql.jdbc.Driver");
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(register.class.getName()).log(Level.SEVERE, null, ex);
            }
            
         String a =request.getParameter("name");
         String b =request.getParameter("u");
         String e =request.getParameter("mail");
         String d =request.getParameter("p");
         String f =request.getParameter("p1");
         /*
          long bb=Long.parseLong(b);
          long dd=Long.parseLong(d);
          */
         
         Connection dbCon = (Connection) DriverManager.getConnection(  
                    "jdbc:mysql://localhost:3306/test1", "root", "admin");  

            
         String query ="insert into authenticate (name,user,password,mail) "+
                 "values ('"+a+"','"+b+"','"+d+"','"+e+"') ";

            Statement stmt = null;
            ResultSet rs = null;
           
            stmt = (Statement) dbCon.prepareStatement(query);

            i = stmt.executeUpdate(query);
           /// out.println(i);
            
            }
       catch (SQLException ex)
        {
                out.println(ex);
        } 
            
            response.setContentType("text/html;charset=UTF-8");
            ////PrintWriter out = response.getWriter();
        try {
            if(i!=0)
            {
                    out.println("<html>");
                    out.println("<head>");
                    out.println("<title> Success</title>");
                    out.println("</head>");
                    out.println("<body background=proj images/2.jpg>");
                    out.println("<p><h1> Successfully SignUped!!!!</h1> </p>");
                    out.println("<a href=Log.jsp>");
                    out.println("LogIn</a>");
                    out.println("</body>");
                    out.println("</html>");
            }
            else{
            //// TODO output your page here
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Signing up Failed!!!!</title>");  
            out.println("</head>");
            out.println("<body>");
            out.println("<a href=signup.jsp> sign up again.....");
            out.println("</a>");
            out.println("</body>");
            out.println("</html>");
            
            }
        } finally {            
            out.close();
        }
    
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
